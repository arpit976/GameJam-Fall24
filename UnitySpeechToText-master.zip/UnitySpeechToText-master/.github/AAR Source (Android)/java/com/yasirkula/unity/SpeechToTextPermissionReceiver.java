package com.yasirkula.unity;

public interface SpeechToTextPermissionReceiver
{
	void OnPermissionResult( int result );
}