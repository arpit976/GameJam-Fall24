= Speech to Text for Android & iOS (v1.1.1) =

Documentation: https://github.com/yasirkula/UnitySpeechToText
Example code: https://github.com/yasirkula/UnitySpeechToText#example-code
E-mail: yasirkula@gmail.com